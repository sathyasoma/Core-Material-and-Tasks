package com.loopingstatements;
//Write a program to print all alphabets from a to z
public class Alphabet6 {
	public static void main(String[] args)
	{
		char s;
		for(s='a';s<='z';s++)
		{
			System.out.println(s);
		}
	}
}
