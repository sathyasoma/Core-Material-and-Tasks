package com.inheritance;
class Dad{
	
	public void sleep() {
		System.out.println("sleep left direction good health");
	}
}
class Mom{
	
	public void sleep() {
		System.out.println("sleep right direction good health");
	}
}
public class Baby extends Mom{
  	
	public static void main(String[] args) {
		
		Baby b= new Baby();
		
		b.sleep();
		
		//multiple inheritane is not possible in javal evel
		//interface level
	}
}
