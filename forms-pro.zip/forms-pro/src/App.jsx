
import './App.css'
import FormValid from './FormValid'

function App() {
  

  return (
    <div>
    <FormValid/>
    </div>
  )
}

export default App
