package com.polymorphism;

public class Calculator {

	public void addition(int a,int b,int c)
	{
		System.out.println("addition of three int paramters is :"+(a+b+c));
	}
	
	public void addition(int a,int b)
	{
		System.out.println("addition of two int paramters are ;"+(a+b));
	}
	
	public void addition(float a,float b)
	{
		System.out.println("addition of two float parmaters are :"+(a+b));
	}
	
	public void addition(int a,float b)
	{
		System.out.println("addition of int,float are :"+(a+b));
	}
	  public void addition(float a,int b)
	  {
		  System.out.println("addition of float ,int are ;"+(a+b));
	  }
	
	public static void main(String[] args) {
		
		Calculator ct= new Calculator();
		ct.addition(12,34,56);
		ct.addition(74,23);
		ct.addition(45.02f, 78);
		ct.addition('a', 'a');//type promotion
	}
}
