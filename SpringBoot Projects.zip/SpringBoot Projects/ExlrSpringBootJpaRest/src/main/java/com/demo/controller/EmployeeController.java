package com.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.Employee;
import com.demo.service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {
	
	@Autowired
	private EmployeeService service;
	
	@PostMapping("/addemp") //http://localhost:4579/emp/addemp
	public Employee addEmployee(@RequestBody Employee emp)
	{
		return service.addEmployee(emp);
	}
	
	@PutMapping("/update/{id}")//http://localhost:4579/emp/update/238
	public Employee updateEmployee(@RequestBody Employee emp)
	{
		return service.updateEmployee(emp);
	}
 
	@GetMapping("/get/{id}") //http://localhost:4579/emp/get/234
	public Employee getEmployee(@PathVariable("id") int empid)
	{
		return service.getEmployee(empid);
	}
	
	@DeleteMapping("/del/{id}")//http://localhost:4579/emp/del/456
	public String deleteEmployee(@PathVariable("id") int empid)
	{
		service.delteEmployee(empid);
		return "employee deleted" ;
	}

	@GetMapping("/getall") //http://localhost:4579/emp/getall
	public List<Employee> getAllEmployees()
	{
		return service.getAllEmployees();
	}
}
