import React from 'react'

import './App.css'
import Navbar from './Components/Navbar'
import Forms from './Components/Forms'


function App() {


  return (
  <>
   <h1>Welcome to Root Component</h1>
  <Navbar/>
  <Forms/>
   </>
  )
}
export default App
