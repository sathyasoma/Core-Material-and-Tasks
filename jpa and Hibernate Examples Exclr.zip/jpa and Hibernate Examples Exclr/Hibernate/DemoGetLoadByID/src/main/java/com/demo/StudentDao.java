package com.demo;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class StudentDao {

	public void getStudent(int id)
	{
		Session session=HibernateUtil.getSessionFactory().openSession();
		Transaction trans=session.beginTransaction();
		Student student=session.get(Student.class,id);
		System.out.println("student first name :"+student.getFirstName());
		System.out.println("student mail id :"+student.getEmail());

		trans.commit();
	}
	
	  public void loadStudent(int id) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        	Transaction  transaction = session.beginTransaction();
	            Student student = session.load(Student.class, id);
	            System.out.println("student first name :"+student.getFirstName());
	            System.out.println("student mail id :"+student.getEmail());
	            transaction.commit();
	  }
	  
	  
	  public void getStudentById(int id) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction   transaction = session.beginTransaction();
	            Student student = session.byId(Student.class).getReference(id);
	            System.out.println("student first name :"+student.getFirstName());
	            System.out.println("student mail id :"+student.getEmail());
	            transaction.commit();	        
	    }
	  
	  
	  public void saveStudent(Student student) {
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        Transaction   transaction = session.beginTransaction();
	            session.persist(student);
	            transaction.commit();
	        
	    }
}
