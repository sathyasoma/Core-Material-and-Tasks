import Cart from "./Cart";
import FlipLogo from "./FlipLogo";
import Login from "./Login";
import SerchBar from "./SerchBar";

function Navbar(){
   
    return(
        <div>
        <h1>WELCOME TO nAVABAR</h1>
        <Cart/>
          <FlipLogo/>
          <SerchBar/>
          <Login/>
         
        </div>
    )
}
   export default Navbar;


 