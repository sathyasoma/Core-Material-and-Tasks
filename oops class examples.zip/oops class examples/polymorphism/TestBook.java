package com.polymorphism;

class Book{
	String title;
	String author;
	double price;
	
	public Book() {
		this.title=title;
		this.author=author;
		this.price=price;
	}
	
	public Book(String title,String author) {
		this.title=title;
		this.author=author;
	}
	public Book(String title,String author,double price) {
		this.title=title;
		this.author=author;
		this.price=price;
	}
	
	public void dispaly()
	{
		System.out.println("Title is :"+title+"->Author is :"+author+"Price ->"+price);
	}
}
public class TestBook {

	public static void main(String[] args) {
		
		Book b= new Book();
		Book b1= new Book("java", "sathya");
		Book b2= new Book("python", "shiva", 900.89);
		
		b.dispaly();
		b1.dispaly();
		b2.dispaly();
		
	}
}
