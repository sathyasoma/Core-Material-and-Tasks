package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Test {

	public static void main(String[] args) {
		
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session s = sf.openSession();

		Transaction t = s.beginTransaction();
		
	
	Employee emp= new Employee("keerthi", 3333);
	
	Address add= new Address("bnglr", "kt", 200078);
	Address add1= new Address("kerala", "kochi", 60098);
	
	emp.getAddress().add(add);
	emp.getAddress().add(add1);
		s.save(emp);
		
		t.commit();
		System.out.println("done");

	}
}
