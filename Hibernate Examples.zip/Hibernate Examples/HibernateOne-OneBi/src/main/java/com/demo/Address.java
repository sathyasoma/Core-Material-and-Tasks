package com.demo;

import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToOne;
import jakarta.persistence.Table;

@Entity
@Table(name="Addres_bitab")
public class Address {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int hnum;
	private String colony;
	private String state;
	private int pincode;
	
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="employee_id")
	private Employee employee;

	public int getHnum() {
		return hnum;
	}

	public void setHnum(int hnum) {
		this.hnum = hnum;
	}

	public String getColony() {
		return colony;
	}

	public void setColony(String colony) {
		this.colony = colony;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getPincode() {
		return pincode;
	}

	public void setPincode(int pincode) {
		this.pincode = pincode;
	}

	public Employee getEmployee() {
		return employee;
	}

	public void setEmployee(Employee employee) {
		this.employee = employee;
	}
	
	public Address() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param colony
	 * @param state
	 * @param pincode
	 * @param employee
	 */
	public Address(String colony, String state, int pincode) {
		super();
		this.colony = colony;
		this.state = state;
		this.pincode = pincode;
		
	}

	@Override
	public String toString() {
		return "Address [hnum=" + hnum + ", colony=" + colony + ", state=" + state + ", pincode=" + pincode
				+ ", employee=" + employee + "]";
	}
	
	
}
