
import './App.css'
import AddProduct from './Components/AddProduct'
import AxiosDemo from './Components/AxiosDemo'
import Deleted from './Components/Deleted'
import GetProducts from './Components/GetProducts'
import Updated from './Components/Updated'


function App() {
 
  
  return (
    <>
     <h2>Welcome to API Integeration</h2>
    {/*  <GetProducts/> 
    <AddProduct/>
    <Updated/> 
    <Deleted/>*/}

    <AxiosDemo/>
    </>
  )
}

export default App
