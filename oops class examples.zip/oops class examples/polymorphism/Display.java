package com.polymorphism;

public class Display {

	public void show(int a)
	{
		System.out.println("showing interger values :"+a);
	}
	public void show(String s)
	{
		System.out.println("showing String values :"+s);
	}
	public void show(char c)
	{
		System.out.println("showing charecters values :"+c);
	}
	
	
	public static void main(String[] args) {
		
		
		Display d= new Display();
		
		d.show("sathya");
		d.show(67);
		d.show('s');
	}
}


