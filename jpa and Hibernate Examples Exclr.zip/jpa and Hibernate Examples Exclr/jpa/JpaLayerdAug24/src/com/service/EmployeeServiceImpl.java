package com.service;

import com.dao.EmployeeDao;
import com.dao.EmployeeDaoImpl;
import com.model.Employee;


public class EmployeeServiceImpl implements EmployeeService {


	private EmployeeDao dao;

	public EmployeeServiceImpl() {

		dao = new EmployeeDaoImpl();
	}

	@Override
	public void addEmployee(Employee emp) {
		dao.beginTrasaction();
		dao.addEmployee(emp);
		dao.commitTrasaction();

	}

	@Override
	public void updateEmployee(Employee emp) {
		dao.beginTrasaction();
		dao.updateEmployee(emp);
		dao.commitTrasaction();

	}

	@Override
	public void deleteEmployee(Employee emp) {
		dao.beginTrasaction();
		dao.deleteEmployee(emp);
		dao.commitTrasaction();

	}

	@Override
	public Employee findEmployeeById(int empid) {
		Employee emp = dao.getEmployeeById(empid);
		return emp;

	}

}
