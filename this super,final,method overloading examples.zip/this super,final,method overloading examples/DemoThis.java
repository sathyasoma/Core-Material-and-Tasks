package com.polymorphism;
class DemoSuper{
	
	int age=10;
	public DemoSuper() {
		this(23);
		System.out.println("i am default of :Parent: :1:"+age);
	}
	public DemoSuper(int marks) {
		this.m2();
		System.out.println("i am param of :Parent: 2:"+marks);
	}
	
	public void m2()
	{
		System.out.println("i am m2 method from parent :3");	
	}
}
public class DemoThis extends DemoSuper{

	int age=20;
	
	public DemoThis() {
		super();
		System.out.println("i am default consctruor of :child: 4 "+age);
		this.m1();
	}
	public void m1()
	{
		System.out.println("i am m1 method from child :5");	
	}
	
	public static void main(String[] args) {
		
		DemoThis dt= new DemoThis();
		
		
	}
}
