package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Employee;

public interface EmployeeService {

	public abstract void addEmployee(Employee employee);

	public abstract void updateEmployee(Employee employee);

	public abstract void removeEmployee(int employee);

	public abstract Employee findEmployeeById(int eid);

	public abstract List<Employee> listEmployee();

}
