function SerchBar()
{
    return(
        <h2>i am serch bar component</h2>
    )
}
export default SerchBar