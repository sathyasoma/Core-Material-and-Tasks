package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Test {

	public static void main(String[] args) {
		
		  SessionFactory sf= HibernateUtil.getSessionFactory();
		  Session session=sf.openSession();
		  
		  Transaction trans=session.beginTransaction();
		
		  Employee emp= new Employee(456, "devasena", 8888, "kuntahala");
		  
		 // session.save(emp);
		  
		  Employee emp1=session.find(Employee.class, 456);
		  System.out.println(emp1);
		  
		  emp1.setEmpadd("complex");
		  emp1.setEmpname("prince");
		  emp1.setEmpsal(55555);
		  
		 // session.merge(emp1);
		  
		  session.remove(emp1);
		  trans.commit();
		  System.out.println("employee deleted sufullyt....");
	}
}
