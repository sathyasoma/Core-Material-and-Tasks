package com.demo;

import com.demo.model.Employee;
import com.demo.service.EmployeeService;
import com.demo.service.EmployeeServiceImpl;

public class Test {

	public static void main(String[] args) {
		
		
		EmployeeService service= new EmployeeServiceImpl();
		
		Employee emp= new Employee(111, "sathya", 9999, "hyd");
		
		//service.addEmployee(emp);
		
		Employee emp1=service.findEmployeeById(111);
		System.out.println(emp1);
		
		emp1.setEmpadd("kuntala");
		emp1.setEmpname("devasena");
		emp1.setEmpsal(66666);
		
		//service.updateEmployee(emp1);
		service.deleteEmployee(emp1);
	}
}
