package com.inheritance;

 class Father{
	
	public void house()
	{
		System.out.println("i have 2bhk house");
	}
}
public class Son extends Father{

	public void car()
	{
		System.out.println("i have RR Car");
	}
	
	public static void main(String[] args) {
		
		Son s= new Son();
		s.car();
		s.house();
		s.house();
	}
}
