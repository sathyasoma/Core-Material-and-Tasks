package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("one");
		EntityManager entity = factory.createEntityManager();

		entity.getTransaction().begin();
		
		Address ad= new Address();
		ad.setColny("london");
		ad.setState("malco");
		ad.setPincode(45000);
		
		Student st= new Student();
		st.setStname("keerthi");
		st.setAddress(ad);
		
		//entity.persist(ad);
		entity.persist(st);
		
		
//		Address add1= entity.find(Address.class,1);
//		add1.setColny("nalgonda");
//		add1.setState("tg");
//		add1.setPincode(508001);
//		Student st1=entity.find(Student.class, 1);
//		//System.out.println(st1);
//		st1.setStname("sathya");
//		st1.setAddress(add1);
		
		
	//	entity.merge(st1);
		//entity.remove(st1);
		entity.getTransaction().commit();
		
		
		
	}
}
