import React from 'react'

const Button = () => {
  return (
    <div>
    <button type="submit">Submit</button>
    </div>
  )
}

export default Button