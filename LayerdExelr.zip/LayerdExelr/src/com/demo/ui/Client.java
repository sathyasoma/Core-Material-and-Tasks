package com.demo.ui;

import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

import com.demo.model.Employee;
import com.demo.service.EmployeeService;
import com.demo.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) {
		
		EmployeeService service= new EmployeeServiceImpl();
		
		while(true)
		{
			System.out.println("****Employee management Appliction***");
			System.out.println("1.Add Employee");
			System.out.println("2.Update Employee");
			System.out.println("3.Get Employee");
			System.out.println("4.Delete EMployee");
			System.out.println("5.Get All Employees");
			
			Scanner sc= new Scanner(System.in);
			int option=sc.nextInt();
			
			switch(option)
			{
			case 1:
				System.out.println("U clicked case-1");
				System.out.println("Enter Employee name");
				String empName=sc.next();
				System.out.println("Enter Employee Salary");
				int empSal=sc.nextInt();
				System.out.println("Enter Employee Address");
				String empAdd=sc.next();
				System.out.println("Enter Employee Emailid");
				String empMail=sc.next();
				
				Employee emp= new Employee(empName, empSal, empAdd, empMail);
				
				int employeeId=service.addEmployee(emp);
				System.out.println("Employee addedd succfully :"+employeeId);
				break;
			case 2:
				System.out.println("U clicked case-2");
				System.out.println("Employee ID To Update Details");
				int empId=sc.nextInt();
				System.out.println("Enter Employee name");
				String empname=sc.next();
				System.out.println("Enter Employee Salary");
				int empsal=sc.nextInt();
				System.out.println("Enter Employee Address");
				String empadd=sc.next();
				System.out.println("Enter Employee Emailid");
				String empmail=sc.next();
				
				Employee emp1= new Employee(empname, empsal, empadd, empmail);
				Employee empobj=service.updateEmployee(empId, emp1);
				System.out.println("employee updated suscfully :"+empId);
				break;
			case 3:
				System.out.println("U clicked case-3");
				System.out.println("Enter Employee Id To get Details");
				int eid=sc.nextInt();
				Employee empob=service.getEmployee(eid);
				System.out.println(empob);
				break;
			case 4:
				System.out.println("U clicked case-4");
				System.out.println("Enter EMPLOYEE ID tO dELETE");
				int eid1=sc.nextInt();
				service.deleteEmployee(eid1);
				System.out.println("EMployee dleeted succfully :"+eid1);
				break;
			case 5:
				System.out.println("U clicked case-5");
				Set<Entry<Integer,Employee>> result=service.getAllEmployees();
				Iterator<Entry<Integer,Employee>> itr=result.iterator();
				while(itr.hasNext())
				{
					Entry<Integer,Employee> finalResult=itr.next();
					System.out.println(finalResult.getKey()+" "+finalResult.getValue());
				}
				break;
			default:
				System.out.println("NO case is matched eneter valid case number");
				break;
			}
			
		}
	}
}
