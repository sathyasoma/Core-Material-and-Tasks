package com.abstarction;

abstract class Shape{
	
	public  abstract void draw();
	
	public void dispaly()
	{
		System.out.println("it is a shape");
	}
}
class Rectangle extends Shape{
	
	double length;
	double bredth;
	
	public Rectangle(double length, double bredth) {
		super();
		this.length = length;
		this.bredth = bredth;
	}



	@Override
	public void draw() {
		System.out.println("Rectangle :"+(length*bredth));	
	}	
}
class Circle extends Shape {
	
	double radius;
	
	public Circle(double radius) {
		super();
		this.radius = radius;
	}
	@Override
	public void draw() {
		System.out.println("Circle: "+(3.14*radius*radius));	
	}
}
public class TestShape {

	public static void main(String[] args) {
		
		Rectangle rect= new Rectangle(78,56);
		//rect.dispaly();
		rect.draw();
		
	Circle  circ= new Circle(78);
	// circ.dispaly();
	 circ.draw();
	}
}
