package com.demo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Test {
public static void main(String[] args) {
	
	Employee emp= new Employee("saoma", 660, "hyd");
	Employee emp1= new Employee("sathya", 4660, "nlg");
	
	Transaction transaction=null;
	
	Session session=HibernateUtil.getSessionFactory().openSession();
	transaction=session.beginTransaction();

	//session.persist(emp);
	//session.persist(emp1);
	
	
	//list of all the students
	List<Employee> li=session.createQuery("from Employee",Employee.class).list();
	
	for(Employee e:li)
	{
		System.out.println(e.getEmpid()+" "+e.getEmpname()+" "+e.getEmpsal()+" "+e.getEmpadd());
	}
	
	transaction.commit();
	System.out.println(" save done");
	
}
}
