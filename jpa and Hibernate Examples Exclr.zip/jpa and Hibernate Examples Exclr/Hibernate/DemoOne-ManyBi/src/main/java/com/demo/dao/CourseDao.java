package com.demo.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.demo.entity.Course;
import com.demo.util.HibernateUtil;


public class CourseDao {
    public void saveCourse(Course course) {
       Session session = HibernateUtil.getSessionFactory().openSession();
        	Transaction transaction = session.beginTransaction();
            session.save(course);
            transaction.commit();
    }

    public void updateCourse(Course course) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        	Transaction transaction = session.beginTransaction();
            session.update(course);
            transaction.commit();
    }

    public void deleteCourse(int id) {

       Session session = HibernateUtil.getSessionFactory().openSession();
        	Transaction  transaction = session.beginTransaction();
            Course course = session.get(Course.class, id);
            if (course != null) {
                session.delete(course);
                System.out.println("course is deleted");
            }
            transaction.commit();
    }

    public Course getCourse(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        	Transaction transaction = session.beginTransaction();
        	Course course = session.get(Course.class, id);
            transaction.commit();
        return course;
    }
}
