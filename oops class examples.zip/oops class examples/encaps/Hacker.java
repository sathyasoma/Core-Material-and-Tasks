package com.encaps;

public class Hacker {

	public static void main(String[] args) {
		
		Student st= new Student();
      
		st.setStuid(1234);
		st.setStmarks(98);
		st.setStname("devasena");
		st.setStadd("kunthala");
		
	System.out.println(st.getStadd()+" "+st.getStmarks()
	+" "+st.getStname()+" "+st.getStuid());
	
	}
}
