import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {
		
	
	
	EntityManagerFactory factory= Persistence.createEntityManagerFactory("singleTable");
	
	EntityManager entity= factory.createEntityManager();
	
	entity.getTransaction().begin();
	//create one employee
	
	Employee employee= new Employee();
	
	employee.setEadd("Delhi");
	
	employee.setEname("taru");
	employee.setEsal(40000);
	
   entity.persist(employee);
	
	Manager mgr= new Manager();
	
	mgr.setEadd("benglr");

	mgr.setEname("mahesh");
	mgr.setEsal(250000);
	mgr.setDepartmentName("marketing DEPRT");
	
	entity.persist(mgr);
	
	
	entity.getTransaction().commit();
	System.out.println("employee, mgr created tables seperated");
	
	
	
	
	
	
	
	
}
}