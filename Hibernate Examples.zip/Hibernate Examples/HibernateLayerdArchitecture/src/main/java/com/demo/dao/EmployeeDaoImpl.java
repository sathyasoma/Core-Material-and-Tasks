package com.demo.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.demo.model.Employee;

public class EmployeeDaoImpl implements EmployeeDao {

	private Session session;

	public EmployeeDaoImpl() {
		SessionFactory sf = HibernateUtil.getSessionFactory();

		 session = sf.openSession();
	}

	@Override
	public Employee getEmployeeById(int empid) {
		Employee emp = session.find(Employee.class, empid);
		return emp;
	}

	@Override
	public void addEmployee(Employee emp) {
		Transaction tr = session.beginTransaction();
		session.save(emp);
		tr.commit();
	}

	@Override
	public void updateEmployee(Employee emp) {
		Transaction tr = session.beginTransaction();
		session.merge(emp);
		tr.commit();

	}

	@Override
	public void deleteEmployee(Employee emp) {
		Transaction tr = session.beginTransaction();
		session.remove(emp);
		tr.commit();
	}


}
