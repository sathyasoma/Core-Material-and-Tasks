package com.demo;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.demo.model.Employee;
import com.demo.service.EmployeeService;
import com.demo.service.EmployeeServiceImpl;

public class Test {

	public static void main(String[] args) {
	
		
		EmployeeService service= new EmployeeServiceImpl();
		
		Employee emp= new Employee(111, "divya", 7717, "nlg");
		
		
		//service.addEmployee(emp);
		Employee e=service.findEmployeeById(111);
		System.out.println(e.getEmpadd()+" "+e.getEmpname()
		+" "+e.getEmpsal());
	    
		e.setEmpadd("lbnagar");
		e.setEmpname("sathya");
		e.setEmpsal(3333);
		
		//service.updateEmployee(e);
		service.deleteEmployee(e);
	}
}
