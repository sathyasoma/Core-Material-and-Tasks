package com.ui;

import com.model.Employee;
import com.service.EmployeeService;
import com.service.EmployeeServiceImpl;

public class Client {

	public static void main(String[] args) {
		
		EmployeeService service= new EmployeeServiceImpl();
		
		Employee emp= new Employee(100, "keerthi", 1000, "kochi");
		
		//service.addEmployee(emp);
		
		Employee employee=service.findEmployeeById(100);
		System.out.println(employee);
		
		employee.setEmpadd("hyd");
		employee.setEmpname("sathya");
		employee.setEmpsal(200);
		
	//	service.updateEmployee(employee);
		service.deleteEmployee(employee);
	}
}
