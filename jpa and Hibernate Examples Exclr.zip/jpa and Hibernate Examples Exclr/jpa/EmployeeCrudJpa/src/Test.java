import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {
	
	public static void main(String[] args) {
		
	EntityManagerFactory factory	=Persistence.createEntityManagerFactory("yourname");
	
          EntityManager entity = factory.createEntityManager();
          
          // persist()-->to save, merge()-->update  remove()-->delete. find()----fetch,
          
//          Employee emp= new Employee(100, "sathya", 1000, "hyd");
//          
//          entity.getTransaction().begin();
//          entity.persist(emp);  // to save  -> dml operations
//          entity.getTransaction().commit();
		
		         Employee emp=entity.find(Employee.class, 100);
		         System.out.println(emp);
		         
		         emp.setEmpAdd("usa");
		         emp.setEmpName("keerthi");
		         emp.setEmpSal(200000);
		         
		         entity.getTransaction().begin(); 
		         //entity.merge(emp);
		         entity.remove(emp);
		         entity.getTransaction().commit();
		         
		         
		
	}

}
