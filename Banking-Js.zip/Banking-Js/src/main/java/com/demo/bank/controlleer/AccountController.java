package com.demo.bank.controlleer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.bank.entity.Account;
import com.demo.bank.service.AccountService;

@RestController
@RequestMapping("/api/accounts")
@CrossOrigin("*")
public class AccountController {
	 @Autowired
	    private AccountService accountService;
	    
	 @GetMapping
	    public List<Account> getAllAccounts() {
	        return accountService.getAllAccounts();
	    }
	    
	    @GetMapping("/{id}")
	    public Account getAccountById(@PathVariable(value = "id") Long accountId) {
	        return accountService.getAccountById(accountId);
	    }
	    
	    @PostMapping
	    public Account createAccount(@RequestBody Account account) {
	        return accountService.createAccount(account);
	    }
	    
	    @PutMapping("/{id}")
	    public Account updateAccount(@PathVariable(value = "id") Long accountId, @RequestBody Account accountDetails) {
	        return accountService.updateAccount(accountId, accountDetails);
	    }
	    
	    @DeleteMapping("/{id}")
	    public ResponseEntity<?> deleteAccount(@PathVariable(value = "id") Long accountId) {
	        return accountService.deleteAccount(accountId);
	    }
}
