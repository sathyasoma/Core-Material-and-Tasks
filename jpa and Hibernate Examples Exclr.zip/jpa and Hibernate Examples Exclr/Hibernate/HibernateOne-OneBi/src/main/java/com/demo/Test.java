package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Test {

	public static void main(String[] args) {
		
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session s = sf.openSession();

		Transaction t = s.beginTransaction();
		
		Employee emp= new Employee("tarun", 4940);
		
	Address add= new Address("knl", "ap", 50076);
	
		emp.setAddress(add);
		add.setEmployee(emp);
		//s.save(emp);
				
		Employee emp1=s.find(Employee.class, 1);
		emp1.setEmpname("mahesh");
		emp1.setEmpsal(22222);
		s.merge(emp1);
		
		
		t.commit();
		System.out.println("done");

	}
}
