package com.demo.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.demo.entity.Instructor;
import com.demo.util.HibernateUtil;


public class InstructorDao {
    public void saveInstructor(Instructor instructor) {
       Session session = HibernateUtil.getSessionFactory().openSession();
        	Transaction transaction = session.beginTransaction();
            session.save(instructor);
            transaction.commit();
    }

    public void updateInstructor(Instructor instructor) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        	Transaction transaction = session.beginTransaction();
            session.update(instructor);
            transaction.commit();
    }

    public void deleteInstructor(int id) {

       Session session = HibernateUtil.getSessionFactory().openSession();
        	Transaction transaction = session.beginTransaction();
            Instructor instructor = session.get(Instructor.class, id);
            if (instructor != null) {
                session.delete(instructor);
                System.out.println("instructor is deleted");
            }
            transaction.commit();
           }

    public Instructor getInstructor(int id) {
        Session session = HibernateUtil.getSessionFactory().openSession();
        	Transaction transaction = session.beginTransaction();
        	Instructor instructor = session.get(Instructor.class, id);
            transaction.commit();
        
        return instructor;
    }
}