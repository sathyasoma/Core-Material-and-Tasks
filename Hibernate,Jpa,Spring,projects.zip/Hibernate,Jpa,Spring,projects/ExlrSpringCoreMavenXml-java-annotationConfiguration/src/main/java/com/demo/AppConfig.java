//package com.demo;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//@ComponentScan("com.demo")
//public class AppConfig {
//
//	//Employee class Bean Creation and passing data
//	
//	@Bean(name="keerthi")
//	public Employee getEmployee()
//	{
//		Employee emp= new Employee();
//		emp.setEmpid(124);
//		emp.setEmpname("kalki");
//		emp.setEmpsal(20000);
//		
//		return emp;
//	}
//	
//	@Bean(name="add")
//	public Address getAddress()
//	{
//		Address add= new Address();
//		add.setColony("saraswathi nagar colony");
//		add.setHunum(2390);
//		add.setState("lb nagar");
//		add.setPincode(500074);
//		
//		return add;
//	}
//}
