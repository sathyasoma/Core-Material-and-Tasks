package com.demo;

import com.demo.dao.CourseDao;
import com.demo.dao.InstructorDao;
import com.demo.entity.Course;
import com.demo.entity.Instructor;

public class Test {
public static void main(String[] args) {
	
	
	 InstructorDao instructorDao = new InstructorDao();
	  CourseDao courseDao = new CourseDao();
	  
	  Instructor instructor = new Instructor("sathya", "prakash", "sathya191916@gmail.com");
	  instructorDao.saveInstructor(instructor);
	  
	  // create some courses
	  Course tempCourse1 = new Course("Air Guitar - The Ultimate Guide");
	  tempCourse1.setInstructor(instructor);
	  courseDao.saveCourse(tempCourse1);  
	  
	  Course tempCourse2 = new Course("The Pinball Masterclass");
	  tempCourse2.setInstructor(instructor);
	  courseDao.saveCourse(tempCourse2);
}
	
}

