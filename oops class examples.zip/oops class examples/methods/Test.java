package com.object.methods;

class Mobile {
	
	String brand;
	double price;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((brand == null) ? 0 : brand.hashCode());
		long temp;
		temp = Double.doubleToLongBits(price);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		
		return true;
	}
	@Override
	public String toString() {
		return "Mobile [brand=" + brand + ", price=" + price + "]";
	}
	

}
public class Test extends  Mobile {

	public static void main(String[] args) {
		
		Mobile mb= new Mobile();
		mb.brand="Apple";
		mb.price=10000;
		
		Mobile mb1= new Mobile();
		mb.brand="Apple";
		mb.price=10000;
		
				
		//boolean result=mb==mb1;
		boolean result= mb.equals(mb1);
		System.out.println(result);//false
		System.out.println(mb);
		System.out.println(mb.toString());//mb.getClass.getName+"@"+HexadEME(hashcode())

		System.out.println(mb.hashCode());
		System.out.println(mb1.hashCode());
		
/*		
a
com.object.methods.Mobile@7852e922
com.object.methods.Mobile@7852e922

b.
com.object.methods.Mobile@7852e928
com.object.methods.Mobile@7852e922

c.
apple 10000
apple 10000

d
apple1 1000
1000 appl2
*/
		
	}
}
