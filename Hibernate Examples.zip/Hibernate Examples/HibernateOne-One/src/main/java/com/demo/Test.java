package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Test {

	public static void main(String[] args) {
		
		SessionFactory sf = HibernateUtil.getSessionFactory();

		Session s = sf.openSession();

		Transaction t = s.beginTransaction();
		
	Address add= new Address("ada", "sa", 440);
	Employee emp= new Employee("dad", 440, add);
		//s.save(emp);
		
	  Address add1=s.find(Address.class, 1);
	  add1.setColony("saraswathi nagar");
	  add1.setState("lb nagar");
      add1.setPincode(500074);
	  
	  Employee emp1=s.find(Employee.class,1);
	   System.out.println(emp1);
	  emp1.setEmpname("divya");
	  emp1.setEmpsal(2222);
	  emp1.setAddress(add1);
	  
	//  s.merge(emp1);
	    
	   s.remove(emp1);        
	
		t.commit();
		System.out.println("done");

	}
}
