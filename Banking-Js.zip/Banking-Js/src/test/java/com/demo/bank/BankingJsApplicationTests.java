package com.demo.bank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BankingJsApplicationTests {

	@Test
	void contextLoads() {
	}

}
