package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {
		
		Configuration cfg=new Configuration();
		cfg.configure("hibernate.cfg.xml");		
		SessionFactory factory=cfg.buildSessionFactory();
		Session session	=factory.openSession();
		Transaction trnas=session.beginTransaction();
		
		Employee emp= new Employee(198, "kulkarni", 7777, "Rajastan");	
		//session.save(emp); //1
		
		Employee emp1=session.find(Employee.class, 198);
		System.out.println(emp1); //2
		
		emp1.setEmpadd("complex");
		emp1.setEmpname("prince");
		emp1.setEmpsal(66666);
		
		//update
		//session.merge(emp1);	 //3	
		session.remove(emp1); //4
		trnas.commit();		
		System.out.println("employee updated succesfully....");
	}
}
