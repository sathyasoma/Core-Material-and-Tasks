package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeCrudWithMavenJpaRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeCrudWithMavenJpaRestApplication.class, args);
		
		
		
	}

}
