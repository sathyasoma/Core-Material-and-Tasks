package com.cust;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Shop {

	@Id
	private int shopid;
	private String shopname;
	private String shopadd;
	
	
	public int getShopid() {
		return shopid;
	}
	public void setShopid(int shopid) {
		this.shopid = shopid;
	}
	public String getShopname() {
		return shopname;
	}
	public void setShopname(String shopname) {
		this.shopname = shopname;
	}
	public String getShopadd() {
		return shopadd;
	}
	public void setShopadd(String shopadd) {
		this.shopadd = shopadd;
	}
	@Override
	public String toString() {
		return "Shop [shopid=" + shopid + ", shopname=" + shopname + ", shopadd=" + shopadd + "]";
	}
	
	
}
