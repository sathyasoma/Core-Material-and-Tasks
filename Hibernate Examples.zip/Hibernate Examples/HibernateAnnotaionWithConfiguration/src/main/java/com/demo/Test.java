package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Test {

	public static void main(String[] args) {

		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session=factory.openSession();
		Transaction trans=session.beginTransaction();
		Employee emp= new Employee(122, "bujji", 8888, "shambala");
		
		//session.save(emp);
		
		Employee emp1=session.find(Employee.class, 122);
		System.out.println(emp1);
		emp1.setEmpadd("complex");
		emp1.setEmpname("minister");
		emp1.setEmpsal(7777);
		
		//session.merge(emp1);
		session.remove(emp1);
		trans.commit();
		System.out.println("Emplpyee delted suffuly");
	}
}
