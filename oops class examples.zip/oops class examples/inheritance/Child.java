package com.inheritance;

public class Child  extends Parent {

	public void m2()
	{
		System.out.println("i am m2 method form child");
	}
	
	public static void main(String[] args) {
		
		Child ch= new Child();
		ch.m2();
		ch.m1();
	}
}
