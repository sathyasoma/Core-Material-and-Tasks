package com.abstarction;

abstract class Test{
	
	public void demo()  //impl
	{
		System.out.println("welcome");
	}
	
	public abstract void travel();//unimpl
}
public class Demo extends Test{
	@Override
	public void travel() {
		System.out.println("travel to india");
	}
	public static void main(String[] args) {
		
		Demo d= new Demo();
		d.demo();
		d.travel();
		
	//	Test t= new Test();//we cant create object of abstarct class
	//	t.demo();
	//	t.travel();
		
	}

	
}
