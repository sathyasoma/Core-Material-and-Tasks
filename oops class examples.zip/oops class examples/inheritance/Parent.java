package com.inheritance;

public class Parent {

	
	public void m1()
	{
		System.out.println("i am m1 method from parent");
	}
}
