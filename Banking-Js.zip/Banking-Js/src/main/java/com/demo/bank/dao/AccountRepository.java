package com.demo.bank.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.demo.bank.entity.Account;

public interface AccountRepository extends JpaRepository<Account, Long>{

}
