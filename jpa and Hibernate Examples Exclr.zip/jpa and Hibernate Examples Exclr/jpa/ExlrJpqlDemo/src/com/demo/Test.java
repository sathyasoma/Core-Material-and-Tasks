package com.demo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class Test {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("keerthi");
		EntityManager entity=factory.createEntityManager();
		
		entity.getTransaction().begin();
		
		Employee emp= new Employee(123, "kalki", 89999, "shamabala");
		Employee emp1= new Employee(345, "barateyudu", 6453, "astrlia");
		Employee emp2= new Employee(198, "maharaja", 28272, "london");
		Employee emp3= new Employee(476, "kill", 65443, "hyd");
		
		
//		entity.persist(emp);
//		entity.persist(emp1);
//		entity.persist(emp2);
//		entity.persist(emp3);
		
		TypedQuery<Employee> tq=entity.createQuery("select e From Employee e",Employee.class);
		
		   List<Employee> li=tq.getResultList();
		
		for(Employee ex:li)
		{
			System.out.println(ex.getEmpadd()+" "+ex.getEmpname()+" "+ex.getEmpsal());
		}
		
		//update
		Query q=entity.createQuery("update Employee set empsal=empsal+5000");
		//q.executeUpdate();
		
		Query q1=entity.createQuery("select MAX(emp.empsal) From Employee emp");
		int maxSal=(int) q1.getSingleResult();
		//System.out.println(maxSal);
		
		Query q3=entity.createQuery("delete From Employee where empsal<80000");
		q3.executeUpdate();
			
		entity.getTransaction().commit();
	}
}
