package com.demo;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Test {
	
	//other way to execute
	/*
	public static void saveOrUpdateStudent(Employee emp) {
        Transaction transaction = null;
       Session session = HibernateUtil.getSessionFactory().openSession();
            transaction = session.beginTransaction();
            // save the student object
            session.saveOrUpdate(emp);
            Employee emp = session.get(Employee.class, 1);
            emp.setEmpname("Ram");
            session.saveOrUpdate(emp);
            transaction.commit();
        
    }
    */

public static void main(String[] args) {
	
	
	Employee emp= new Employee("tarun", 5847, "kurnool");
	//persistEmployee(emp);
	Session session=HibernateUtil.getSessionFactory().openSession();
	Transaction trans=session.beginTransaction();
	
	session.saveOrUpdate(emp);
	System.out.println("updating the name of employe.......");
	emp.setEmpname("mahesh");
	session.saveOrUpdate(emp);
	trans.commit();
	System.out.println("Employee saved or updated");
}
}