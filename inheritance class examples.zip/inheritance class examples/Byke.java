package com.inheritance;

class Vechile{
	
	
	
}
class Car{
	
	
}
public class Byke {

}
