package com.demo.service;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.demo.dao.EmployeeDao;
import com.demo.dao.EmployeeDaoImpl;
import com.demo.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	private EmployeeDao dao;

	public EmployeeServiceImpl() {
		dao = new EmployeeDaoImpl();
	}

	@Override
	public void addEmployee(Employee emp) {
		dao.addEmployee(emp);

	}

	@Override
	public void updateEmployee(Employee emp) {
		dao.updateEmployee(emp);

	}

	@Override
	public void deleteEmployee(Employee emp) {
		dao.deleteEmployee(emp);
	}

	@Override
	public Employee findEmployeeById(int empid) {
		Employee emp = dao.getEmployeeById(empid);
		return emp;
	}

}
