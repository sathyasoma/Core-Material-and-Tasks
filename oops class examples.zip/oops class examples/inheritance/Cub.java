package com.inheritance;
//multilevel
class Animal{ //gp
	
	public void eat()
	{
		System.out.println("every animal can eat");
	}
}

class Lion extends Animal{//p
	
	public void care()
	{
		System.out.println("lion is caring about cub");
	}
}

public class Cub extends Lion { //ch

	public void play()
	{
		System.out.println("the cub is playing ");
	}
	public static void main(String[] args) {
		
		Cub  cb= new Cub();
		cb.play();
		cb.care();
		cb.eat();
	}
}
