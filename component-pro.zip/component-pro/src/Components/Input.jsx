import React from 'react'

const Input = () => {
  return (
    <div>
     Enter deatils: <input type="text" placeholder='Enter Input'/>
    </div>
  )
}

export default Input