package com.strings;
//Write a program to get a substring of a given string between two specified positions

public class Specified_Position22 {

	public static void main(String[] args)
	{
		String str = "Tarun Soma Computer Education";
		String new_str = str.substring(11, 20);
		System.out.println("Given String : " + str);
		System.out.println("SubString of a given String : " +new_str);
	}
}
