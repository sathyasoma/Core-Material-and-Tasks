import React from 'react'
import { useEffect } from 'react'
const Updated = () => {

        
useEffect( 

    updateNewProduct()
 ,[]
 )
 
  async function updateNewProduct()
   {
    let updated= await fetch('https://fakestoreapi.com/products/17',{
        method:"PUT",
        body:JSON.stringify(
            {
                title: 'test product',
                price: 13.5,
                description: 'lorem ipsum set',
                image: 'https://i.pravatar.cc',
                category: 'sathya'
            }
        )
    })

    let finalaRes=await updated.json();
    console.log(finalaRes)
   }
  return (
    <div>Updated</div>
  )
}

export default Updated