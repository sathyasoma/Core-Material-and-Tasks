package com.demo;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import oracle.net.jdbc.TNSAddress.Address;

@Entity
@Table(name="sostudent")
public class Student {

	@Id
	private int stid;
	private String stname;
	private int stmarks;
	private String stadd; //hyd

	public int getStid() {
		return stid;
	}

	public void setStid(int stid) {
		this.stid = stid;
	}

	public String getStname() {
		return stname;
	}

	public void setStname(String stname) {
		this.stname = stname;
	}

	public int getStmarks() {
		return stmarks;
	}

	public void setStmarks(int stmarks) {
		this.stmarks = stmarks;
	}

	public String getStadd() {
		return stadd;
	}

	public void setStadd(String stadd) {
		this.stadd = stadd;
	}

	public Student() {
		// TODO Auto-generated constructor stub
	}

	public Student(int stid, String stname, int stmarks, String stadd) {
		super();
		this.stid = stid;
		this.stname = stname;
		this.stmarks = stmarks;
		this.stadd = stadd;
	}

	@Override
	public String toString() {
		return "Student [stid=" + stid + ", stname=" + stname + ", stmarks=" + stmarks + ", stadd=" + stadd + "]";
	}
	

}
