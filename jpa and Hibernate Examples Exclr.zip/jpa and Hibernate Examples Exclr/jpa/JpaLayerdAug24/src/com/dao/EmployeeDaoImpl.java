package com.dao;

import javax.persistence.EntityManager;

import com.model.Employee;


public class EmployeeDaoImpl implements EmployeeDao {
	
	private EntityManager entity;
	
	public EmployeeDaoImpl() {
		entity=JpaUtil.getEntityManagaer();
	}

	@Override
	public Employee getEmployeeById(int empid) {
		Employee emp= entity.find(Employee.class, empid);
		return emp;
	}

	@Override
	public void addEmployee(Employee emp) {
		entity.persist(emp);
		
	}

	@Override
	public void updateEmployee(Employee emp) {
		entity.merge(emp);
		
	}

	@Override
	public void deleteEmployee(Employee emp) {

      entity.remove(emp);
		
	}

	@Override
	public void beginTrasaction() {
		
		entity.getTransaction().begin();
	}

	@Override
	public void commitTrasaction() {
		entity.getTransaction().commit();
		
	}

}
