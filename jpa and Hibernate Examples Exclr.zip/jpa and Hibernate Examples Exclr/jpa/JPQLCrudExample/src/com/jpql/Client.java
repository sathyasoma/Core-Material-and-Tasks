package com.jpql;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Client {
public static void main(String[] args) {
	
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("priyanka");
	EntityManager entity=factory.createEntityManager();
	
	entity.getTransaction().begin();
	
//	Employee employee= new Employee(452, "keerthi", 47800, "triventrum");
//	Employee employee1= new Employee(125, "PRIYANKA", 7800, "KOCHI");
//	Employee employee2= new Employee(784, "SONUSUDH", 9000, "TAMILNADU");
//	Employee employee3= new Employee(129, "KATTAPPA", 10000, "BENGULURU");
//	
//	
//	entity.persist(employee);
//	entity.persist(employee1);
//	entity.persist(employee2);
//	entity.persist(employee3);
	
	
	//update
	
//	TypedQuery<Employee> tq=entity.createQuery("select e from Employee e",Employee.class);
//	List<Employee> li=tq.getResultList();
//	
//	for(Employee e:li) {
//		System.out.println(e.getEmpadd());
//		System.out.println(e.getEmpname());
//		System.out.println(e.getEmpsal());
//	}
	
//	Query q1=entity.createQuery("update Employee set empsal=empsal+5000 where  empsal<60000");
//	
//	q1.executeUpdate();
	
		/*
		 * Query q2=entity.createQuery("delete from Employee where empid=129");
		 * 
		 * q2.executeUpdate();
		 */
	
	
	
	Query q3=entity.createQuery("select MAX(emp.empsal) FROM Employee emp");
	int maxsal=(int) q3.getSingleResult();
	System.out.println(maxsal);
	entity.getTransaction().commit();
	
	
	
}
}
