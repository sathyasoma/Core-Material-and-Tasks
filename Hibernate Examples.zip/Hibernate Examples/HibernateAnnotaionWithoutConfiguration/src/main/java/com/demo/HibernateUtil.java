package com.demo;



import java.util.Properties;

import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.cfg.Environment;
import org.hibernate.service.ServiceRegistry;

public class HibernateUtil {
	
	private static SessionFactory sessionFactory;
	
	public static SessionFactory getSessionFactory()
	{
		
		Configuration cfg= new Configuration();
		
		//hibernate.cfg.xml properties fro java level
		
		Properties settings= new Properties();
		settings.put(Environment.DRIVER, "com.mysql.cj.jdbc.Driver");
		settings.put(Environment.URL, "jdbc:mysql://localhost:3306/hi");
		settings.put(Environment.USER, "root");
		settings.put(Environment.PASS, "Sathya@123");
		
		settings.put(Environment.SHOW_SQL, "true");
		settings.put(Environment.HBM2DDL_AUTO, "create-drop");
		
		cfg.setProperties(settings);
		
		cfg.addAnnotatedClass(Employee.class);
		
		ServiceRegistry  serviceRegistry = new StandardServiceRegistryBuilder()
				.applySettings(cfg.getProperties()).build();
		sessionFactory = cfg.buildSessionFactory(serviceRegistry);

		return sessionFactory;
	}

}
