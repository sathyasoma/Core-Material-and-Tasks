package com.polymorphism;
class ParentWel{
	
	int age=76;//parent global variable
	
	public void m1()
	{
		System.out.println("parent m1 method");
	}
	
	public ParentWel() {
		System.out.println("parent class default constcrutor");
	}
}
public class Wel extends ParentWel{

	int age = 50;// global variable

	public void m1()
	{
		System.out.println("i am m1 method of child");
	}
	
	public Wel() {
		//super();
	}
	public void getAge(int age) {
	
		System.out.println("my age is :" + age);
		System.out.println("my age is :" + this.age);
		System.out.println("my parent age is :"+super.age);
		this.m1();
		super.m1();
		System.out.println(this);
	}

	public static void main(String[] args) {
		Wel wel = new Wel();
		wel.getAge(56);

	}
}
