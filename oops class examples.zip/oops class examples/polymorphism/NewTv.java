package com.polymorphism;



class OldTv{
	
	public void sound()
	{
		System.out.println("sound is 50 dz its good");
	}
	
	public void screen()
	{
		System.out.println("it is lcd screen");
	}
}
public class NewTv  extends OldTv{

	@Override
	public void screen()
	{
		System.out.println("logic is LED TV");
	}
	
	public static void main(String[] args) {
		
		NewTv nt= new NewTv();
		nt.screen();
		nt.sound();
		
	}
}
