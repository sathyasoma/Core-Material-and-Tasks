package com.demo.service;

import java.util.List;
import java.util.Optional;

import com.demo.entity.Employee;

public interface EmployeeService {

	public abstract Employee addEmployee(Employee employee);

	public abstract Employee updateEmployee(Employee employee);

	public List<Employee> findEmployeeByName(String ename);

	public abstract void removeEmployee(int empId);

	public abstract Optional<Employee> findEmployeeById(int eid);

	public abstract List<Employee> listEmployee();

	public List<Employee> getAllInBetween(int initialSal, int salary);
}
