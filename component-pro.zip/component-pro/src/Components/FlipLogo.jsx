function FlipLogo()
{
 return(
     <h2>i ma flipcart logo</h2>
 )
}
export default FlipLogo