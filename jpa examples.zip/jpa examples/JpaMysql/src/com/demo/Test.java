package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {
		
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("mystudent");
		
		EntityManager entity=factory.createEntityManager();
		
		entity.getTransaction().begin();
		
		Student st= new Student(100, "divya",56	, "kurnool");
		//entity.persist(st);
		
		Student student=entity.find(Student.class, 100);
	//	System.out.println(student);
		//student.setStadd("hyd");
		//student.setStmarks(96);
		
		//entity.merge(student);
		entity.remove(student);
		entity.getTransaction().commit();
		
		
		
	}
}
