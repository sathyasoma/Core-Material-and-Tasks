package com.polymorphism;

 class ParentFinal{
	 int age=77; //we cant change final variabls
	
	public  void getAge(int age)
	{
		this.age=++age;
		System.out.println("my parent age is :"+this.age);
	}	
}
public class FinalDemo extends ParentFinal{ //cant extend final class

	@Override
	public void getAge(int age) //final methods cant override
	{
		this.age=--age;//65
		System.out.println("my child age is :"+this.age);
	}	
	public static void main(String[] args) {
		
		FinalDemo fd= new FinalDemo();
		fd.getAge(66);//66 65 67,75,77,76
		
	}
}
