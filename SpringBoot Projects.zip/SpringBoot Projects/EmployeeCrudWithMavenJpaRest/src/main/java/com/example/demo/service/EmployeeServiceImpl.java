package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.dao.EmployeeDao;
import com.example.demo.entity.Employee;



@Service("employeeService")
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeDao dao;
	
	
	@Override
	public void addEmployee(Employee employee) {
		dao.addEmployee(employee);//persist()
		
	}

	@Override
	public void updateEmployee(Employee employee) {
		dao.updateEmployee(employee);//persist()
		
	}

	@Override
	public void removeEmployee(int employee) {
		dao.removeEmployee(employee);
		
	}

	@Override
	public Employee findEmployeeById(int eid) {
		Employee emp = dao.getEmployeeById(eid);
		return emp;
	}

	@Override
	public List<Employee> listEmployee() {
		List<Employee> l1 = dao.listEmployee();

		return l1;
	}
	
}