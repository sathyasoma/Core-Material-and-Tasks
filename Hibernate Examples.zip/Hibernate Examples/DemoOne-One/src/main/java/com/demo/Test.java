package com.demo;

import com.demo.dao.InstructorDao;
import com.demo.entity.Instructor;
import com.demo.entity.InstructorDetail;

public class Test {
public static void main(String[] args) {
	
	
	Instructor instructor = new Instructor("sathya", "prakash", "sathya@gmail.com");
    InstructorDetail instructorDetail = new InstructorDetail("http://www.youtube.com", "drums");
    instructor.setInstructorDetail(instructorDetail);

    InstructorDao instructorDao = new InstructorDao();
    instructorDao.saveInstructor(instructor);
	
}
}
