package com.abstarction;

interface Interf{
	
	 public abstract void demo();
            abstract void demo1();
	                 void  demo2();//
}

public class DemoInterface implements Interf{

	
	public static void main(String[] args) {
		
		
		//Interf ify= new Interf();
	}

	@Override
	public void demo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void demo1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void demo2() {
		// TODO Auto-generated method stub
		
	}
}
