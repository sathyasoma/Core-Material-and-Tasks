package com.ui;

import com.model.Employee;
import com.service.EmployeeService;
import com.service.EmployeeServiceImpl;

public class Test {

	public static void main(String[] args) {
		
	 EmployeeService service= new EmployeeServiceImpl();
	 
	 Employee emp= new Employee(852, "ravi", 12000, "kochi");
	 
	 service.addEmployee(emp);
		
		
		
	}
}
