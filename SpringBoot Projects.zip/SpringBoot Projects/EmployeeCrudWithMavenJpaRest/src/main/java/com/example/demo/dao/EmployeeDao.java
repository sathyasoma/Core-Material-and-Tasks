package com.example.demo.dao;

import java.util.List;

import com.example.demo.entity.Employee;

public interface EmployeeDao {

	public abstract Employee getEmployeeById(int eid);

	public abstract void addEmployee(Employee emp);

	public abstract void removeEmployee(int emp);

	public abstract void updateEmployee(Employee emp);

	public abstract List<Employee> listEmployee();

}
