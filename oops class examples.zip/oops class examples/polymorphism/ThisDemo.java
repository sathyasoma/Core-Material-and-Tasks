package com.polymorphism;

class SuperDemo{

	int salary=55000;
	
	public void getSalary(int salary)
	{
		salary=65000;
		System.out.println("my parent salary is :"+salary);
	}
}
public class ThisDemo extends SuperDemo{
	int salary=25000;
	
	public void getSalary(int salary)
	{
		salary=35000;
		System.out.println("my salary is :"+salary);
		System.out.println("my global salary is :"+this.salary);
		System.out.println(this);
		super.getSalary(75000);
		System.out.println("my parent global salary :"+super.salary);
	}	
public static void main(String[] args) {
	
	ThisDemo td= new ThisDemo();
	td.getSalary(45000);//25,35,45
	//System.out.println(td);
}
}
