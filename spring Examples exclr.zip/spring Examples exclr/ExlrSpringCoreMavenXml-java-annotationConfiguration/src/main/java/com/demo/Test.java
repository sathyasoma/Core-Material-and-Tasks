package com.demo;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Configuration
@ComponentScan("com.demo")
public class Test {

	public static void main(String[] args) {
			
//		Resource resource= new ClassPathResource("SpringConfig.xml");
//		BeanFactory factory= new XmlBeanFactory(resource);
		
		//xml way configuration
	//	ApplicationContext factory= new ClassPathXmlApplicationContext("SpringConfig.xml");
	    //java configuration
	//	ApplicationContext factory= new AnnotationConfigApplicationContext(AppConfig.class);
	        //annotation configuration
		ApplicationContext factory= new AnnotationConfigApplicationContext(Test.class);
	
		/*
		Address add= (Address) factory.getBean("address");
		add.setColony("uadaya");
		add.setHunum(467);
		add.setPincode(90067);
		add.setState("kphp");
		
		Employee emp=(Employee) factory.getBean("employee");
		emp.setEmpid(345);
		emp.setEmpname("barateyudu2");
		emp.setEmpsal(46464);
		
		System.out.println(emp);
		*/
		
	/*	
//Understanding the scopes
		//singletone: 
		
		Employee emp=(Employee) factory.getBean("employee");
		Employee emp1=(Employee) factory.getBean("employee");
		
		System.out.println(emp);
		System.out.println(emp1);
*/		
		/*
		//prototype: 
		
		Employee emp=(Employee) factory.getBean("employee");
		Employee emp1=(Employee) factory.getBean("employee");
		
		System.out.println(emp);
		System.out.println(emp1);		
		*/
		
		Employee emp=(Employee) factory.getBean("employee");
		System.out.println(emp);
	}
}
