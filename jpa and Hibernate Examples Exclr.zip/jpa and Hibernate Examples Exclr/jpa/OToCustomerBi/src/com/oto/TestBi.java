package com.oto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class TestBi {
public static void main(String[] args) {
	
	
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("cusBi");
	EntityManager entity=factory.createEntityManager();
	
	entity.getTransaction().begin();
	
	ShopBi sb= new ShopBi();
	
	sb.setShoname("janaki");
	sb.setShopadd("hyd");
    
	
	CustomerBi custo= new CustomerBi();
	custo.setCusadd("goa");
	custo.setCusname("swami");
	custo.setShop(sb);
	
	entity.persist(custo);
	
	entity.getTransaction().commit();
}
}
