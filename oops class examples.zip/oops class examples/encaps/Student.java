package com.encaps;

public class Student {

	//private memebers
	private int stuid=45;//two methods //123
	private String stname="bahu";
	private String stadd="mahish";
	private int stmarks=89;
	
	
	public int getStuid() {
		return stuid;
	}
	public void setStuid(int stuid) {
		this.stuid = stuid; //123
	}
	public String getStname() {
		return stname;
	}
	public void setStname(String stname) {
		this.stname = stname;
	}
	public String getStadd() {
		return stadd;
	}
	public void setStadd(String stadd) {
		this.stadd = stadd;
	}
	public int getStmarks() {
		return stmarks;
	}
	public void setStmarks(int stmarks) {
		this.stmarks = stmarks;
	}
	
	
	
	
	//getters and setters
	
	
}
