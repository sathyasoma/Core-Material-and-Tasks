package com.jpa.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

public static void main(String[] args) {
	
	
	
	EntityManagerFactory factory=Persistence.createEntityManagerFactory("mydemo");
	
	EntityManager entity=factory.createEntityManager();
	
	//Employee emp= new Employee(100, "pandu", 10000, "hyd");
	
	
	//persist()=>to save or insert; merge()==>to update;  remove()==>to delete; DML: find()==>to fetch 
	//insert
	
	//entity.getTransaction().begin();
	//entity.persist(emp);
	//entity.getTransaction().commit();
	
	
	//fetch
		Employee emp=entity.find(Employee.class, 100);//only  1 record
		System.out.println(emp);
	
	//update
//	emp.setEmpAdd("ooty");
//	emp.setEmpsal(56202);
//	emp.setEmpname("keerthi suresh");
////	
//	entity.getTransaction().begin();
//	entity.merge(emp);
//	entity.getTransaction().commit();
	
	entity.getTransaction().begin();
	entity.remove(emp);
	entity.getTransaction().commit();
//	
}	
}
