package com.inheritance;
//multilevel inheritance

class GrnadParent{
	
	public void property()
	{
		System.out.println("i have 1000 crore property");
	}
}
class Parents extends GrnadParent{
	
	public void house()
	{
		System.out.println("i have 3bhk house");
	}
	
}
public class GrandSon extends Parents {

	public void car()
	{
		System.out.println("i have benz car....");
	}
	public static void main(String[] args) {
		
		GrandSon gs= new GrandSon();
		gs.car();
		gs.house();
		gs.property();
	}
}
