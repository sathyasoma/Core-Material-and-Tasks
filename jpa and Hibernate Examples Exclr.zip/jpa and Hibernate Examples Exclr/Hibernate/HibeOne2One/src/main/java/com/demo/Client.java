package com.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Client {

	public static void main(String[] args) {
		
		
		SessionFactory factory=HibernateUtil.getSessionFactory();
		Session session=factory.openSession();
		
		Transaction trans=session.beginTransaction();
		
		Address add= new Address("kphb", "nellore", 500074);
		Employee emp= new Employee("kalki", 2777, add);
		
		//session.save(emp);
	//	session.save(add);
		
		Address add1= session.find(Address.class, 1);
		add1.setColony("hitechcity");
		Employee emp1=session.find(Employee.class, 1);
		System.out.println(emp1);
		
		emp1.setEmpname("devasena");
		emp1.setEmpsal(45555);
		emp1.setAddress(add1);
		
		//session.merge(emp1);
		
		session.remove(emp1);
		trans.commit();
		System.out.println("done");
		
	}
}
