import React from 'react'
import { useEffect } from 'react'

const Deleted = () => {

           
useEffect( 

    deleteNewProduct()
 ,[]
 )
 
  async function deleteNewProduct()
   {
    let deleted = await fetch('https://fakestoreapi.com/products/6',{
        method:"DELETE"
    })

    let finalaRes=await deleted.json();
    console.log(finalaRes)
   }
  return (
    <div>Deleted</div>
  )
}

export default Deleted