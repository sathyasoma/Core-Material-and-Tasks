package com.demo.service;

import java.util.List;
import java.util.Optional;

import com.demo.model.Employee;

public interface EmployeeService {

	// Employee amangement Serviece

	Employee addEmployee(Employee emp);

	Employee updateEmployee(Employee emp);

	Optional<Employee> getEmployee(int empid);

	Object deleteEmployee(int empid);

	List<Employee> getAllEmployees();
}
