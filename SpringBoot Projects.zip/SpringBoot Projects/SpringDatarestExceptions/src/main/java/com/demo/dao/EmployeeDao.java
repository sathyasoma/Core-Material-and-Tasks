package com.demo.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.demo.entity.Employee;

public interface EmployeeDao extends JpaRepository<Employee, Integer> {
	
@Query("select e from Employee e where esal between ?1 and ?2")
public List<Employee> getAllInBetween(int initialSal,int salary);

public List<Employee> findByEname(String ename);
//
//public List<Employee> findByEsalBetween(Integer initialSal,Integer salary);
//
//
//public List<Employee> findByEname(String ename );
//public List<Employee> findByCity(String cit );
}
//
//fetch all student byname
//fetch students by marks inbetween
//....