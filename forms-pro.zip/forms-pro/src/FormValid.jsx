import React, { useEffect } from 'react'
import { useState } from 'react'

const FormValid = () => {

  const initialValues={username:'',email:'',password:''}
  const[formValues,setFormValues]=useState(initialValues)
 const[formErrors,setFormErrors]=useState({})
 const[isSubmit,setIsSubmit]=useState(false)


  const handleChange =(e) =>{

    const {name,value} =e.target;
    setFormValues({
        ...formValues,[name]:value
    })
  }

  const handleSubmit =(e) =>{
       e.preventDefault();
       setFormErrors(validate(formValues));
       setIsSubmit(true);

  }

 useEffect(

   ()=>{
        console.log(formErrors)
        if(Object.keys(formValues).length===0 && isSubmit)
        {console.log(formValues)}
   },[formErrors]

 )



 const validate =(values) =>{
    
    const errors={};

    const regex=/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/i;
    

    if(!values.username)
    {
        errors.username = "Username is Required..."
    }
    if(!values.email)
    {
        errors.email="Email is Required..."
    }else if(!regex.test(values.email))
    {
        errors.email = " This is not a valid email...."
    }

    if(!values.password)
    {
        errors.password = "Password is Required..."
    }else if(values.password.length<5)
    {
        errors.password="Password must be at least 5 characters"
    }
    else if(values.password.length>10)
    {
        errors.password="Password must be less tahn 10 charecters...."
    }
    return errors;
 }

  return (
    <form onSubmit={handleSubmit}>
     
    {
        Object.keys(formValues).length ===0 && isSubmit ?
        (<p>hel</p>) :
        (<pre>{JSON.stringify(formValues,undefined,5)}</pre>)
    }
    


    <div>
    <h2>Login Form</h2>
    </div>
    <div>
        <label>Username :</label>
        <input
        type="text"
        name="username"
        placeholder='Enter username'
        value={formValues.username}
        onChange={handleChange}
        />
        <p style={{color:'red'}}>{formErrors.username}</p>
    </div>
    <div>
        <label>Email :</label>
        <input
        type="email"
        name="email"
        placeholder='Enter Email id'
        value={formValues.email}
        onChange={handleChange}
        />
        <p style={{color:'red'}}>{formErrors.email}</p>
    </div>
    <div>
        <label>Password :</label>
        <input
        type="text"
        name="password"
        placeholder='Enter Password'
        value={formValues.password}
        onChange={handleChange}
        />
        <p style={{color:'red'}}>{formErrors.password}</p>
    </div>
    
    <button type='submit'>Submit</button>
    </form>
  )
}

export default FormValid