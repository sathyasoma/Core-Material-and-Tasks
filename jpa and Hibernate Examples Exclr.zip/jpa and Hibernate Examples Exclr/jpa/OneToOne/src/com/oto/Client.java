package com.oto;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
public static void main(String[] args) {
	
	EntityManagerFactory factory= Persistence.createEntityManagerFactory("otojpa");
	
	EntityManager entity=factory.createEntityManager();
	entity.getTransaction().begin();
	
	Department1 department= new Department1();
	department.setD_id(120);
	department.setD_name("devp");
	
	//entity.persist(department);
	
	Employee employee= new Employee();
	
	employee.setEadd("hhd");
	employee.setEid(100);
	employee.setEname("ssp");
	employee.setDep(department);
	
	entity.persist(employee);
	
	entity.getTransaction().commit();
	entity.close();
	factory.close();
	System.out.println("inserted");
	
}

}
