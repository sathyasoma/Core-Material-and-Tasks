import React from 'react'
import Input from './Input'
import Button from './Button'

const Forms = () => {
  return (
    <div>
      <Input/>
      <Input/>
      <Button/>
      
    </div>
  )
}

export default Forms