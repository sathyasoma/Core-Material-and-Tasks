import React from 'react';

function Greet()
{
  return(
    <h1>I am the Child Component</h1>
  )

}
export default Greet;