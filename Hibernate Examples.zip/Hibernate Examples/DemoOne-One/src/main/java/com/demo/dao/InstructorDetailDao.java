package com.demo.dao;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.demo.entity.InstructorDetail;
import com.demo.util.HibernateUtil;

public class InstructorDetailDao {

	public void saveInstructorDetail(InstructorDetail instructorDetail) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		session.save(instructorDetail);
		transaction.commit();
	}

	public void updateInstructorDetail(InstructorDetail instructorDetail) {
		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		session.update(instructorDetail);
		transaction.commit();
	}

	public InstructorDetail getInstructorDetail(int id) {

		Session session = HibernateUtil.getSessionFactory().openSession();
		Transaction transaction = session.beginTransaction();
		InstructorDetail instructor = session.get(InstructorDetail.class, id);
		transaction.commit();
		return instructor;
	}
}