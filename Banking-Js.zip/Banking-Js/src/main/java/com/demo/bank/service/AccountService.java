package com.demo.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.demo.bank.dao.AccountRepository;
import com.demo.bank.entity.Account;
import com.demo.bank.exceptions.ResourceNotFoundException;

@Service
public class AccountService {

	 @Autowired
	    private AccountRepository accountRepository;
	    
	    public List<Account> getAllAccounts() {
	        return accountRepository.findAll();
	    }
	    
	    public Account getAccountById(Long accountId) {
	        return accountRepository.findById(accountId)
	                                .orElseThrow(() -> new ResourceNotFoundException("Account", "id", accountId));
	    }
	    
	    public Account createAccount(Account account) {
	        return accountRepository.save(account);
	    }
	    
	    public Account updateAccount(Long accountId, Account accountDetails) {
	        Account account = accountRepository.findById(accountId)
	                                           .orElseThrow(() -> new ResourceNotFoundException("Account", "id", accountId));
	        
	        account.setAccountNumber(accountDetails.getAccountNumber());
	        account.setBalance(accountDetails.getBalance());
	        
	        return accountRepository.save(account);
	    }
	    
	    public ResponseEntity<?> deleteAccount(Long accountId) {
	        Account account = accountRepository.findById(accountId)
	                                           .orElseThrow(() -> new ResourceNotFoundException("Account", "id", accountId));
	        
	        accountRepository.delete(account);
	        
	        return ResponseEntity.ok().build();
	    }
}
