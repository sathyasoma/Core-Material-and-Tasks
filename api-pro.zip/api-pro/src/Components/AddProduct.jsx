import React from 'react'
import { useEffect } from 'react'

const AddProduct = () => {

      
useEffect( 

    addNewProduct()
 ,[]
 )
 
  async function addNewProduct()
   {
    let inserted= await fetch('https://fakestoreapi.com/products',{
        method:"POST",
        body:JSON.stringify(
            {
                title: 'test product',
                price: 13.5,
                description: 'lorem ipsum set',
                image: 'https://i.pravatar.cc',
                category: 'electronic'
            }
        )
    })

    let finalaRes=await inserted.json();
    console.log(finalaRes)
   }


  return (
    <div>AddProduct</div>
  )
}

export default AddProduct