package com.polymorphism;
class Animal{
	
	public void discribe(String name)
	{
		System.out.println("this ia a :"+name);
	}
	public void discribe(String name,int age)
	{
		System.out.println("this ia a :"+name+" and "+age);
	}
}
class Dog extends Animal {
	
	public void discribe(String name,String breed)
	{
		System.out.println("this is a :"+name +" breed is :"+breed);
	}
}
public class TestPoly {

	public static void main(String[] args) {
		
		Dog d= new Dog();
		d.discribe("bruno");
		d.discribe("bruno", "goldenretriver");
	}
}
