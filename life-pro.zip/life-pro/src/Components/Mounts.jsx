import React from 'react';

class Mounts extends React.Component {
constructor(props) {
    super(props);

    this.state = {
        name:"sathya"
    };
    console.log("constructor called....")
}
componentDidMount()
{
   this.setState({name:"prakash"});
}

    render() {
        return <div>
         {this.state.name}
        
        </div>;
    }
}

export default Mounts;