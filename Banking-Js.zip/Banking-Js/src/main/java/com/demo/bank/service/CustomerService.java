package com.demo.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.demo.bank.dao.CustomerRepository;
import com.demo.bank.entity.Customer;
import com.demo.bank.exceptions.ResourceNotFoundException;

@Service
public class CustomerService {
	@Autowired
    private CustomerRepository customerRepository;
    
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }
    
    public Customer getCustomerById(Long customerId) {
        return customerRepository.findById(customerId)
                                 .orElseThrow(() -> new ResourceNotFoundException("Customer", "id", customerId));
    }
    
    public Customer createCustomer(Customer customer) {
        return customerRepository.save(customer);
    }
    
    public Customer updateCustomer(Long customerId, Customer customerDetails) {
        Customer customer = customerRepository.findById(customerId)
                                              .orElseThrow(() -> new ResourceNotFoundException("Customer", "id", customerId));
        
        customer.setName(customerDetails.getName());
        customer.setAddress(customerDetails.getAddress());
        
        return customerRepository.save(customer);
    }
    
    public ResponseEntity<?> deleteCustomer(Long customerId) {
        Customer customer = customerRepository.findById(customerId)
                                              .orElseThrow(() -> new ResourceNotFoundException("Customer", "id", customerId));
        
        customerRepository.delete(customer);
        
        return ResponseEntity.ok().build();
    }
}
