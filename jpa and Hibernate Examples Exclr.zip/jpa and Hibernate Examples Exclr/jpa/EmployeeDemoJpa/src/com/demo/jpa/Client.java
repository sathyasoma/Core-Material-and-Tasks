package com.demo.jpa;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {

	public static void main(String[] args) {
		
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager entity=factory.createEntityManager();
		
		//save-->persist(), fetch==>find(), delete==>remove(), update==>merge()
		
		//Employee emp= new Employee(100, "tulasi", 45000, "usa");
		
		entity.getTransaction().begin();
		//entity.persist(emp);
		
		
		Employee emp=entity.find(Employee.class, 100);
		    System.out.println(emp);
		    emp.setEmpadd("london");
		    emp.setEmpname("kanim");
		   // entity.merge(emp);
		    entity.remove(emp);
		
		
		
		entity.getTransaction().commit();
		
		entity.close();
		factory.close();
		System.out.println("inserted");
	
	}
}
