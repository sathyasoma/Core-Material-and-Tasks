package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Test {

	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("sathya");
		EntityManager entity=factory.createEntityManager();
		
		entity.getTransaction().begin();
		
		
		Employee emp= new Employee("keerthi", 0, "delhi");	
		//entity.persist(emp);
		
		
		
		Employee emp1=entity.find(Employee.class, 4);
		System.out.println(emp1);
		emp1.setEmpadd("hyd");
		emp1.setEmpname("rajesh");
		emp1.setEmpsal(10000);
		
		//entity.merge(emp1);
		entity.remove(emp1);
		entity.getTransaction().commit();
		System.out.println("employee addedd sucfully");
	}
}
