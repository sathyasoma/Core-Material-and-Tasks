package com.demo.bank.controlleer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.bank.entity.Customer;
import com.demo.bank.service.CustomerService;
@RestController
@RequestMapping("/api/customers")
@CrossOrigin("*")
public class CustomerController {
	 @Autowired
	    private CustomerService customerService;
	    
	 @GetMapping
	    public List<Customer> getAllCustomers() {
	        return customerService.getAllCustomers();
	    }
	    
	    @GetMapping("/{id}")
	    public Customer getCustomerById(@PathVariable(value = "id") Long customerId) {
	        return customerService.getCustomerById(customerId);
	    }
	    
	    @PostMapping
	    public Customer createCustomer(@RequestBody Customer customer) {
	        return customerService.createCustomer(customer);
	    }
	    
	    @PutMapping("/{id}")
	    public Customer updateCustomer(@PathVariable(value = "id") Long customerId, @RequestBody Customer customerDetails) {
	        return customerService.updateCustomer(customerId, customerDetails);
	    }
	    
	    @DeleteMapping("/{id}")
	    public ResponseEntity<?> deleteCustomer(@PathVariable(value = "id") Long customerId) {
	        return customerService.deleteCustomer(customerId);
	    }
}
