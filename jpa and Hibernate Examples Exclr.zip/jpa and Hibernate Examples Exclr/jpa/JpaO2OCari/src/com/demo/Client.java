package com.demo;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Client {
	
	public static void main(String[] args) {
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("O2O");
		
		EntityManager entity=factory.createEntityManager();
		
		entity.getTransaction().begin();
		
		Laptop l1= new Laptop();
		l1.setLid(101);
		l1.setLname("dell");
		
		Student st= new Student();
		
		st.setSid(1);
		st.setSname("jaysimha");
		st.getLaptop().add(l1);
		
		entity.persist(st);
		entity.persist(l1);
		
		entity.getTransaction().commit();
	}

}
