package com.kt.jpqlex;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class Client {
	public static void main(String[] args) {

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("jpqlex");

		EntityManager entity = factory.createEntityManager();

		entity.getTransaction().begin();

//inserted
////	
//	Employee e= new Employee(100, "dIVYA", 10000, "KNL");
//	Employee e1= new Employee(101, "TARUN", 12000, "KURNOOL");
//	Employee e2= new Employee(102, "SATHYA", 13000, "HYD");
//	Employee e3= new Employee(103, "MAHESH", 14000, "KMPL");
////	
//	entity.persist(e);
//	entity.persist(e1);
//	entity.persist(e2);
//	entity.persist(e3);

		// createQuery()--fetch, executeUpdate()--->to update, executeUpdate()--->to
		// delete

//fetch   select * from employeejpql ;

//	
//	TypedQuery<Employee> tq=entity.createQuery("select e from Employee e", Employee.class);
//	
//	List<Employee> li=tq.getResultList();
//			
//	for(Employee s:li) 
//	{
//		
//		System.out.println(s.getEmpId());
//		System.out.println(s.getEmpName());
//		System.out.println(s.getEmpSal());
//		
//	}

//update	
//
//Query result=entity.createQuery("update Employee set empSal= empSal+50000 where empSal>10000");
//          
//              result.executeUpdate();

//delete
//         
		Query result = entity.createQuery("delete from  Employee where empSal>10000");
		result.executeUpdate();

//select

//	           Query result=entity.createQuery("select MAX(e.empSal) FROM Employee e");
//	           
//	                   int maxsal= (int) result.getSingleResult();
//	                   
//	                   System.out.println(maxsal);

		entity.getTransaction().commit();

		entity.close();
		factory.close();
		System.out.println("inserted");

	}

}
