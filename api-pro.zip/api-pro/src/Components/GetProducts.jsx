import React from 'react'
import { useEffect } from 'react'
import axios from 'axios'

const GetProducts = () => {
    
useEffect( 

    getProducts()
 ,[]
 )
 
  async function getProducts()
   {
    // let result= await  fetch('http://localhost:9078/api/accounts/getall')
    //  let res= await result.json();

        let result =await axios.get('http://localhost:9078/api/accounts/getall')
     console.log(result.data)
   }
  return (
    <div>GetProducts</div>
  )
}

export default GetProducts;