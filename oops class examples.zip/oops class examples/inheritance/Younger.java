package com.inheritance;

class Fathr{
	
	public void meet()
	{
		System.out.println("want to meet both childs");
	}
}

class Elder extends Fathr{
	
	public void uSa()
	{
		System.out.println("going to usa want to meet daad..");
	}
	
}
public class Younger extends Fathr {

	public void bdy()
	{
		System.out.println("today my bdy...waiting for dad...cake");
	}
	
	public static void main(String[] args) {
		
		Younger yg= new Younger();
		yg.bdy();
		yg.meet();
		
		
		Elder ed= new Elder();
		ed.uSa();
		ed.meet();
	}
}
