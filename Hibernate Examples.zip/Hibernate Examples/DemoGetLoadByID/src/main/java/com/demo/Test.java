package com.demo;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

public class Test {
public static void main(String[] args) {
	
	
	 StudentDao studentDao = new StudentDao();

     Student student = new Student("Ramesh", "Fadatare", "sathya191916@gmail.com");
     Student student1 = new Student("Tom", "Cruise", "soma@gmail.com");
     Student student2 = new Student("Tony", "stark", "prakash@gmail.com");
     studentDao.saveStudent(student);
     studentDao.saveStudent(student1);
     studentDao.saveStudent(student2);

     studentDao.getStudent(1);
     studentDao.loadStudent(2);
     studentDao.getStudentById(3);
	
}
}
