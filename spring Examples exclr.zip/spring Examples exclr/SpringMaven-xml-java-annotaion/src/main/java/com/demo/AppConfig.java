//package com.demo;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.ComponentScan;
//import org.springframework.context.annotation.Configuration;
//
//@Configuration
//@ComponentScan("com.demo")
//public class AppConfig {
//
//	
//	@Bean("sathya")
//	public Employee getEmployee()
//	{
//		Employee emp= new Employee();
//		
//		emp.setEname("sathya");
//	    emp.setEsal(4566);	
//	    emp.setEid(789);
//	    return emp;
//	}
//	
//	@Bean("add")
//	public Address getAddress()
//	{
//		Address add= new Address();
//		
//		add.setColony("sara");
//		add.setState("tg");
//		add.setStreetNum(4521);
//		
//		return add;
//	}
//}
