package com.loopingstatements;
//Write a program to print reverse alphabets from Z to AWrite a program to print all alphabets from a to z
public class Reverse_Alphabet7 {
	public static void main(String[] args)
	{
		char s;
		for(s='Z';s>='A';s--)
		{
			System.out.println(s);
		}
	}
}
