package com.demo.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.demo.model.Employee;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;


@Repository
@Transactional
public class EmployeeDaoImpl implements EmployeeDao{
	
	@PersistenceContext//got the entity object
	private EntityManager entity;
	

	@Override
	public Employee addEmployee(Employee emp) {
		entity.persist(emp);
		return entity.find(Employee.class, emp.getEmpid());
	}

	@Override
	public Employee updateEmployee(Employee emp) {
		
		return entity.merge(emp);
	}

	@Override
	public Employee getEmployee(int empid) {
		Employee empobj=entity.find(Employee.class, empid);
		return empobj;
	}

	@Override
	public String delteEmployee(int empid) {
		Employee result=entity.find(Employee.class, empid);
		if(result!=null)
		{
			entity.remove(result);
			return "employee deleted susfully";
			
		}else
		{
		return "no employee found";
		}
	}

	@Override
	public List<Employee> getAllEmployees() {
	   TypedQuery<Employee> tq=entity.createQuery("select c from Employee c",Employee.class);
		return tq.getResultList();//jpql
	}

}
