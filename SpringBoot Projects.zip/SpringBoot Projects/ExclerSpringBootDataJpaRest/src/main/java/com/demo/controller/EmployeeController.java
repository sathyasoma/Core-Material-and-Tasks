package com.demo.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.demo.model.Employee;
import com.demo.service.EmployeeService;

@RestController
@RequestMapping("/emp")
public class EmployeeController {

	@Autowired
	private EmployeeService service;
	
	@PostMapping("/add") //http://localhost:6429/emp/add
	public Employee addEmployee(@RequestBody Employee emp) //jackson jar
	{
		return service.addEmployee(emp);
	}
	
	@PutMapping("/update")
	public Employee updateEmployee(@RequestBody Employee emp)
	{
		return service.updateEmployee(emp);
	}
	
	@GetMapping("/get/{id}")
	public Optional<Employee> getEmployee(@PathVariable("id") int empid)
	{
		return service.getEmployee(empid);
	}
	
	@DeleteMapping("/del/{id}")
	public String deleteEmployee(@PathVariable("id") int empid)
	{
		service.deleteEmployee(empid);
		return "employee delted succfully";
	}
	
	@GetMapping("/getall")
	public List<Employee> getAllEmployees()
	{
		return service.getAllEmployees();
	}
}
