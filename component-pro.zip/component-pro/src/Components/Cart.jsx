function Cart()
{

  return (
    <h2>I am the cart component</h2>
  )
}
export default Cart