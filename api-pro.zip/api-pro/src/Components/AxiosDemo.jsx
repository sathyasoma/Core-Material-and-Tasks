import React from 'react'
import axios from 'axios'
import { useEffect } from 'react'

const AxiosDemo = () => {
  
    const instance = axios.create({
        baseURL: 'http://localhost:9078/api/accounts/'   
      });
    
    useEffect(
        
            getPro()
        ,[]
    )
   
    async function getPro()
    {
       let res=await instance.get('/getall')
       let res1=await instance.post("/create")
       console.log(res.data)
       console.log(res1.data)
    }
    

  return (
    <div>AxiosDemo</div>
  )
}

export default AxiosDemo