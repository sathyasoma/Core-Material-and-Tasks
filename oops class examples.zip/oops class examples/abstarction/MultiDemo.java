package com.abstarction;

interface Mom {
	public void sleep();
	public void demo();
}
interface Dad extends Mom {
	public void sleep();
}

public class MultiDemo implements Mom, Dad {

	@Override
	public void sleep() {
		System.out.println("i am sleeping anyway");
	}

	public static void main(String[] args) {

		
		MultiDemo md= new MultiDemo();
		md.sleep();
		md.demo();
	}

	@Override
	public void demo() {
System.out.println("i am demo");		
	}

}
