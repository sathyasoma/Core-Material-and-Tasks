package com.inheritance;

public class User {

	public void read()
	{
		System.out.println("i can read");
	}
	public static void main(String[] args) {
		
		User user= new User();
		user.read();
		
	}
}
