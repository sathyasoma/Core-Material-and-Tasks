package com.demo.ui;

import com.demo.entity.Employee;
import com.demo.service.EmployeeService;
import com.demo.service.EmployeeServiceImpl;

public class Test {

	public static void main(String[] args) {
		
		EmployeeService service = new EmployeeServiceImpl();
		Employee emp= new Employee(100, "nithin", 45000, "hyd");
		
		//service.addEmployee(emp);
		Employee emp1=service.findEmployeeById(100);
		//System.out.println(emp1);
		emp1.setEmpadd("goa");
		emp1.setEmpname("dulkarsalman");
		emp1.setEmpsal(10000);
		//service.updateEmployee(emp1);
		service.deleteEmployee(emp1);
	}
}
