import React from 'react';

class Updates extends React.Component {
constructor(props) {
    super(props);

    this.state = {
        name:"kalakeya"
    };
}

componentDidMount()
{
    console.log("componentDidMount().....")
}

changeState()
{
    this.setState(
        {name:"Bahubali"}
    )
}
    render() {
        return <div>
          <h2>Welcome to Updating State</h2>
          {this.state.name}
          <a onClick={this.changeState.bind(this)} >Click Me</a>
        </div>;
    }

    shouldComponentUpdate(nextProps,nextState)
    {
        console.log("shouldComponentUpdate()........")
        return true;
    }

    componentDidUpdate()
    {
        console.log("componentDidUpdate()...")
    }
}

export default Updates;