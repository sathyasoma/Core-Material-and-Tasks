package com.demo.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;


@Entity
@Table(name = "empmav_info")
public class Employee {
	@Id
	@GeneratedValue
	@Column(length = 12)
	private int eid;
	@Column(length = 12)
	//@NotBlank(message = "Name is mandatory")
	//@NotNull(message="name as null not allowed ")
	//@Min(value=6,message="name length must be above 6")
	private String ename;
	//@Positive(message="Enter valid salary")
	//@Min(value=10000,message="Salary must be above 10000")
	private Integer esal;
	@Column(length = 12)
	private String city;

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public int getEsal() {
		return esal;
	}

	public void setEsal(int esal) {
		this.esal = esal;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public int getEid() {
		return eid;
	}

	public void setEid(int eid) {
		this.eid = eid;
	}

	public Employee(
			//@NotBlank(message = "Name is mandatory") @NotNull(message = "name as null not allowed ") String ename,
			//@Positive(message = "Enter valid salary") @Min(value = 10000, message = "Salary must be above 10000") Integer esal,
			String city) {
		super();

		this.ename = ename;
		this.esal = esal;
		this.city = city;
	}

	public Employee(int eid,
			//@NotBlank(message = "Name is mandatory") @NotNull(message = "name as null not allowed ") String ename,
			//@Positive(message = "Enter valid salary") @Min(value = 10000, message = "Salary must be above 10000") Integer esal,
			String city) {
		super();
		this.eid = eid;
		this.ename = ename;
		this.esal = esal;
		this.city = city;
	}

	public Employee() {
		// TODO Auto-generated constructor stub
	}
}
