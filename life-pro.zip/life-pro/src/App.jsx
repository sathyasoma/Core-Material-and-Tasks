
import './App.css'
import Mounts from './Components/Mounts'
import Updates from './Components/Updates'

function App() {
  
  return (
    <>
     <h1>Welcome to Life Cycle OF REACT</h1>
    {/*}
     <Mounts
     greet="Good Morning.."
     /> */}
     <Updates/>
    </>
  )
}

export default App
