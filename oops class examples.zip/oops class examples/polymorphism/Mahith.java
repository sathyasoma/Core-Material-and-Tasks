package com.polymorphism;
class MathiTpARENTS{
	
	public void property()
	{
		System.out.println("1000 crores property ");
	}
	
	public void marrige()
	{
		System.out.println("we are looking for arrange marrige");
	}
}
public class Mahith extends MathiTpARENTS {

	public void job()
	{
		System.out.println("40 lacks/annum");
	}
	
	@Override
	public void marrige()
	{
		System.out.println("i am looking for love maarige");
	}
	
	public static void main(String[] args) {
		Mahith mt= new Mahith();
		mt.job();
		mt.property();
		mt.marrige();
	}
}
